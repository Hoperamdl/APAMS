USE [Automatedpayroll_Capstone]
GO

/****** Object:  Table [dbo].[employee]    Script Date: 12/5/2018 1:26:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[employee](
	[emp_id] [varchar](50) NULL,
	[lname] [varchar](50) NULL,
	[fname] [varchar](50) NULL,
	[mname] [varchar](50) NULL,
	[gender] [varchar](50) NULL,
	[bmonth] [varchar](50) NULL,
	[bday] [varchar](50) NULL,
	[byear] [varchar](50) NULL,
	[address] [varchar](50) NULL,
	[age] [varchar](50) NULL,
	[bplace] [varchar](50) NULL,
	[cno] [varchar](50) NULL,
	[position] [varchar](50) NULL,
	[status] [varchar](50) NULL,
	[datehired] [varchar](50) NULL,
	[image] [varchar](50) NULL,
	[bioname] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


