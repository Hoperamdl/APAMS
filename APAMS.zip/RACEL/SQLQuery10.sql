USE [Automatedpayroll_Capstone]
GO

/****** Object:  Table [dbo].[wdays]    Script Date: 12/5/2018 1:27:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[wdays](
	[no_wdays] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


