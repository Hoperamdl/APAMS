USE [Automatedpayroll_Capstone]
GO

/****** Object:  Table [dbo].[summary]    Script Date: 12/5/2018 1:26:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[summary](
	[summaryid] [int] IDENTITY(1,1) NOT NULL,
	[employeeno] [int] NULL,
	[employeename] [varchar](50) NULL,
	[department] [varchar](50) NULL,
	[lowrequirement] [varchar](50) NULL,
	[lowactual] [varchar](50) NULL,
	[latet] [varchar](50) NULL,
	[latemin] [varchar](50) NULL,
	[earlyleavet] [varchar](50) NULL,
	[earlyleavemin] [varchar](50) NULL,
	[otreq] [varchar](50) NULL,
	[otsp] [varchar](50) NULL,
	[attendance] [varchar](50) NULL,
	[bonustime] [varchar](50) NULL,
	[absent] [varchar](50) NULL,
	[late] [varchar](50) NULL,
	[bpreq] [varchar](50) NULL,
	[bpover] [varchar](50) NULL,
	[bpalw] [varchar](50) NULL,
	[pdlel] [varchar](50) NULL,
	[pdl] [varchar](50) NULL,
	[pdod] [varchar](50) NULL,
	[actualpay] [varchar](50) NULL,
	[statuspay] [varchar](50) NULL,
	[date] [varchar](50) NULL,
	[time] [varchar](50) NULL,
	[status] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


