USE [Automatedpayroll_Capstone]
GO

/****** Object:  Table [dbo].[payrollstorage]    Script Date: 12/5/2018 1:26:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[payrollstorage](
	[emp_id] [varchar](50) NULL,
	[lname] [varchar](50) NULL,
	[fname] [varchar](50) NULL,
	[mname] [varchar](50) NULL,
	[position] [varchar](50) NULL,
	[datehired] [varchar](50) NULL,
	[workingdays] [varchar](50) NULL,
	[basicpay] [varchar](50) NULL,
	[grosspay] [varchar](50) NULL,
	[cashadvance] [varchar](50) NULL,
	[sss] [varchar](50) NULL,
	[pagibig] [varchar](50) NULL,
	[philhealth] [varchar](50) NULL,
	[others] [varchar](50) NULL,
	[deductions] [varchar](50) NULL,
	[netpay] [varchar](50) NULL,
	[status] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


