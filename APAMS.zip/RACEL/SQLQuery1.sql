USE [Automatedpayroll_Capstone]
GO

/****** Object:  Table [dbo].[cashadvandce]    Script Date: 12/5/2018 1:25:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[cashadvandce](
	[emp_id] [varchar](50) NULL,
	[lname] [varchar](50) NULL,
	[fname] [varchar](50) NULL,
	[mname] [varchar](50) NULL,
	[amount] [varchar](50) NULL,
	[date] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


