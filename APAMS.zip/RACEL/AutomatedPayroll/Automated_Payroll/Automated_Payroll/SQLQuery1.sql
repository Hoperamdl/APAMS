create table login(
id int identity,
username varchar (50),
password varchar (50)
)

create table employee(
emp_id varchar (50),
lname varchar (50),
fname varchar (50),
mname varchar (50),
gender varchar (50),
bday varchar (50),
age varchar (50),
bplace varchar (50),
cno varchar (50),
position varchar (50),
status varchar (50),
datehired varchar (50),
image varchar (50),
)

create table payroll(
emp_id varchar (50),
lname varchar (50),
fname varchar (50),
mname varchar (50),
position varchar (50),
status varchar (50),
datehired varchar (50),
workingdays varchar (50),
basicpay varchar (50),
grosspay varchar (50),
cashadvance varchar (50),
sss varchar (50),
pagibig varchar (50),
philhealth varchar (50),
others varchar (50),
deductions varchar (50),
netpay varchar (50),
)

create table cashadvandce (
emp_id varchar (50),
lname varchar (50),
fname varchar (50),
mname varchar (50),
amount varchar (50),
date varchar (50)
)

create table changeposition(
position varchar (50),
contrate varchar (50),
regrate varchar (50)
)

create table deductions(
emp_id varchar (50),
sss varchar (50),
pagibig varchar (50),
philhealth varchar (50)
)

create table wdays(
no_wdays varchar (50)
)


