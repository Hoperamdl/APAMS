﻿Imports System.Data
Imports System.Data.SqlClient
Module ModuleAdmin
    Public Function exec2(ByVal command2 As String) As DataTable
        Dim dt2 As New DataTable
        Try
            Dim conn2 As String = "Data Source=GATUS-PC\SQLEXPRESS;Initial Catalog=admin;Integrated Security=True"
            Dim sqlDA2 As New SqlDataAdapter(command2, conn2)
            sqlDA2.Fill(dt2)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dt2
    End Function

    Public SQLCON2 As New SqlConnection
    Public sqlcmd2 As SqlCommand
    Public sqlconstr2 As New SqlConnection
    Public res2 As SqlDataReader
    Public cmd2 As String
    Public Sub sqlconnection2()
        If SQLCON2.State = 1 Then SQLCON2.Close()
        SQLCON2.ConnectionString = "Data Source=GATUS-PC\SQLEXPRESS;Initial Catalog=admin;Integrated Security=True"
        Try
            sqlcmd2 = New System.Data.SqlClient.SqlCommand
            SQLCON2.Open()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error in Database Connection")
        End Try
    End Sub
    Public Function Query2(ByVal command2 As String) As String
        sqlconnection2()
        sqlcmd2.Connection = SQLCON2
        cmd2 = command2
        sqlcmd2.CommandText = cmd2
        res2 = sqlcmd2.ExecuteReader
        Return True
    End Function
End Module
