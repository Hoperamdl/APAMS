﻿
Public Class frmUpdateEmployee

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Hide()
    End Sub

    Sub cel()
        Dim dt As New DataTable
        dt = exec("update employee set LAST_NAME = '" & ln.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set FIRST_NAME = '" & fn.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set MIDDLE_NAME = '" & mn.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set BIRTH_MONTH = '" & birthmonth1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set BIRTHDAY = '" & birhday1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set BIRTH_YEAR = '" & birthyear1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set AGE = '" & Label8.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set BIRTH_PLACE = '" & bplace1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set ADDRESS = '" & address1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set CONTACT_NUMBER = '" & cno1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set GENDER = '" & gender1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set POSITION = '" & position1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set STATUS = '" & status1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set DATE_START = '" & datestart.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set DATE_END = '" & dateend.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set IMAGE = '" & PictureBox2.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        dt = exec("update employee set BIONAME = '" & TextBox1.Text & "' where EMPLOYEE_ID ='" & empid1.Text & "' ")
        frmdashboard.Usercontrol_employeerecord1.datagridshow()
        MsgBox("Success")
    End Sub
    Private Sub add1_Click(sender As Object, e As EventArgs) Handles add1.Click
        Try
            cel()
            frmdashboard.Usercontrol_employeerecord1.refress()
            frmdashboard.Usercontrol_employeerecord1.datagridshow()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub browse1_Click(sender As Object, e As EventArgs) Handles browse1.Click
        Dim opf As New OpenFileDialog
        opf.Filter = "Choose Image (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif"

        If opf.ShowDialog = DialogResult.OK Then
            PictureBox2.Image = Image.FromFile(opf.FileName)
        End If
    End Sub
    Sub age()
        If birthyear1.Text = "" Or Label8.Text < 0 Then
            Label8.Text = "0"
        Else

            Dim myAge As New Integer
            myAge = DateTime.Today.Year - birthyear1.Text
            Label8.Text = myAge.ToString()
        End If

    End Sub
    Private Sub bday1_onValueChanged(sender As Object, e As EventArgs)
        Dim myAge As New Integer
        myAge = DateTime.Today.Year - birthyear1.Text
        Label8.Text = myAge.ToString()
    End Sub
   
    Private Sub frmAddEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub ln_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ln.KeyPress
        Static PrevLetterCat As Char
        If PrevLetterCat = " " Or ln.Text.Length = 0 Then
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
        PrevLetterCat = e.KeyChar

        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowedChars As String = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowedChars.Contains(e.KeyChar.ToString) Then
                e.KeyChar = ChrW(0)
                e.Handled = True
                MsgBox("Enter Letters Only")
            End If
        End If
    End Sub

    Private Sub fn_KeyPress(sender As Object, e As KeyPressEventArgs) Handles fn.KeyPress
        Static PrevLetterCat As Char
        If PrevLetterCat = " " Or fn.Text.Length = 0 Then
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
        PrevLetterCat = e.KeyChar

        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowedChars As String = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowedChars.Contains(e.KeyChar.ToString) Then
                e.KeyChar = ChrW(0)
                e.Handled = True
                MsgBox("Enter Letters Only")
            End If
        End If
    End Sub

    Private Sub mn_KeyPress(sender As Object, e As KeyPressEventArgs) Handles mn.KeyPress
        Static PrevLetterCat As Char
        If PrevLetterCat = " " Or mn.Text.Length = 0 Then
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
        PrevLetterCat = e.KeyChar

        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowedChars As String = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowedChars.Contains(e.KeyChar.ToString) Then
                e.KeyChar = ChrW(0)
                e.Handled = True
                MsgBox("Enter Letters Only")
            End If
        End If
    End Sub

    Private Sub cno1_KeyPress(sender As Object, e As KeyPressEventArgs)
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") _
                   AndAlso e.KeyChar <> ControlChars.Back AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> "," AndAlso e.KeyChar <> "/" Then
            e.Handled = True
        End If
    End Sub

    Private Sub save1_Click(sender As Object, e As EventArgs)
        cel()
        frmdashboard.Usercontrol_employeerecord1.refress()
        frmdashboard.Usercontrol_employeerecord1.datagridshow()

    End Sub

    


    Private Sub delete1_Click(sender As Object, e As EventArgs) Handles delete1.Click
        exec("Update employee set STATUS = 'Resigned' where EMPLOYEE_ID =  '" & empid1.Text & "' ")
        exec("Update employee set BIONAME = 'None' where EMPLOYEE_ID = '" & empid1.Text & "' ")
        MsgBox("Success")
    End Sub

    Private Sub Panel6_Paint(sender As Object, e As PaintEventArgs) Handles Panel6.Paint

    End Sub
End Class