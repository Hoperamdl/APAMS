﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSelectAction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSelectAction))
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.mn = New System.Windows.Forms.TextBox()
        Me.fn = New System.Windows.Forms.TextBox()
        Me.ln = New System.Windows.Forms.TextBox()
        Me.empid1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.deductions1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.printempinfo1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.payroll1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.cashadv1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 10
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.mn)
        Me.Panel2.Controls.Add(Me.fn)
        Me.Panel2.Controls.Add(Me.ln)
        Me.Panel2.Controls.Add(Me.empid1)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(5, 29)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(435, 109)
        Me.Panel2.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Candara", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(295, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 18)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Middle Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Candara", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(190, 75)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 18)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "First Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Candara", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(55, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 18)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Last Name"
        '
        'mn
        '
        Me.mn.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mn.Location = New System.Drawing.Point(290, 52)
        Me.mn.Name = "mn"
        Me.mn.Size = New System.Drawing.Size(102, 23)
        Me.mn.TabIndex = 20
        '
        'fn
        '
        Me.fn.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fn.Location = New System.Drawing.Point(158, 52)
        Me.fn.Name = "fn"
        Me.fn.Size = New System.Drawing.Size(126, 23)
        Me.fn.TabIndex = 19
        '
        'ln
        '
        Me.ln.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ln.Location = New System.Drawing.Point(33, 52)
        Me.ln.Name = "ln"
        Me.ln.Size = New System.Drawing.Size(119, 23)
        Me.ln.TabIndex = 18
        '
        'empid1
        '
        Me.empid1.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.empid1.Location = New System.Drawing.Point(103, 14)
        Me.empid1.Name = "empid1"
        Me.empid1.Size = New System.Drawing.Size(161, 23)
        Me.empid1.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Candara", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(5, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 18)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Employee ID:"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.deductions1)
        Me.Panel3.Controls.Add(Me.printempinfo1)
        Me.Panel3.Controls.Add(Me.payroll1)
        Me.Panel3.Controls.Add(Me.cashadv1)
        Me.Panel3.Location = New System.Drawing.Point(5, 138)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(435, 109)
        Me.Panel3.TabIndex = 24
        '
        'deductions1
        '
        Me.deductions1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.deductions1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.deductions1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.deductions1.BorderRadius = 5
        Me.deductions1.ButtonText = "         DEDUCTIONS"
        Me.deductions1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.deductions1.DisabledColor = System.Drawing.Color.Gray
        Me.deductions1.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deductions1.Iconcolor = System.Drawing.Color.Transparent
        Me.deductions1.Iconimage = CType(resources.GetObject("deductions1.Iconimage"), System.Drawing.Image)
        Me.deductions1.Iconimage_right = Nothing
        Me.deductions1.Iconimage_right_Selected = Nothing
        Me.deductions1.Iconimage_Selected = Nothing
        Me.deductions1.IconMarginLeft = 0
        Me.deductions1.IconMarginRight = 0
        Me.deductions1.IconRightVisible = True
        Me.deductions1.IconRightZoom = 0.0R
        Me.deductions1.IconVisible = True
        Me.deductions1.IconZoom = 85.0R
        Me.deductions1.IsTab = False
        Me.deductions1.Location = New System.Drawing.Point(213, 55)
        Me.deductions1.Name = "deductions1"
        Me.deductions1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.deductions1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.deductions1.OnHoverTextColor = System.Drawing.Color.White
        Me.deductions1.selected = False
        Me.deductions1.Size = New System.Drawing.Size(205, 35)
        Me.deductions1.TabIndex = 12
        Me.deductions1.Text = "         DEDUCTIONS"
        Me.deductions1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.deductions1.Textcolor = System.Drawing.Color.White
        Me.deductions1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'printempinfo1
        '
        Me.printempinfo1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.printempinfo1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.printempinfo1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.printempinfo1.BorderRadius = 5
        Me.printempinfo1.ButtonText = "PRINT EMPLOYEE INFO"
        Me.printempinfo1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.printempinfo1.DisabledColor = System.Drawing.Color.Gray
        Me.printempinfo1.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.printempinfo1.Iconcolor = System.Drawing.Color.Transparent
        Me.printempinfo1.Iconimage = CType(resources.GetObject("printempinfo1.Iconimage"), System.Drawing.Image)
        Me.printempinfo1.Iconimage_right = Nothing
        Me.printempinfo1.Iconimage_right_Selected = Nothing
        Me.printempinfo1.Iconimage_Selected = Nothing
        Me.printempinfo1.IconMarginLeft = 0
        Me.printempinfo1.IconMarginRight = 0
        Me.printempinfo1.IconRightVisible = True
        Me.printempinfo1.IconRightZoom = 0.0R
        Me.printempinfo1.IconVisible = True
        Me.printempinfo1.IconZoom = 85.0R
        Me.printempinfo1.IsTab = False
        Me.printempinfo1.Location = New System.Drawing.Point(213, 14)
        Me.printempinfo1.Name = "printempinfo1"
        Me.printempinfo1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.printempinfo1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.printempinfo1.OnHoverTextColor = System.Drawing.Color.White
        Me.printempinfo1.selected = False
        Me.printempinfo1.Size = New System.Drawing.Size(205, 35)
        Me.printempinfo1.TabIndex = 11
        Me.printempinfo1.Text = "PRINT EMPLOYEE INFO"
        Me.printempinfo1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.printempinfo1.Textcolor = System.Drawing.Color.White
        Me.printempinfo1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'payroll1
        '
        Me.payroll1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.payroll1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.payroll1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.payroll1.BorderRadius = 5
        Me.payroll1.ButtonText = "         PAYROLL"
        Me.payroll1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.payroll1.DisabledColor = System.Drawing.Color.Gray
        Me.payroll1.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.payroll1.Iconcolor = System.Drawing.Color.Transparent
        Me.payroll1.Iconimage = CType(resources.GetObject("payroll1.Iconimage"), System.Drawing.Image)
        Me.payroll1.Iconimage_right = Nothing
        Me.payroll1.Iconimage_right_Selected = Nothing
        Me.payroll1.Iconimage_Selected = Nothing
        Me.payroll1.IconMarginLeft = 0
        Me.payroll1.IconMarginRight = 0
        Me.payroll1.IconRightVisible = True
        Me.payroll1.IconRightZoom = 0.0R
        Me.payroll1.IconVisible = True
        Me.payroll1.IconZoom = 80.0R
        Me.payroll1.IsTab = False
        Me.payroll1.Location = New System.Drawing.Point(17, 55)
        Me.payroll1.Name = "payroll1"
        Me.payroll1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.payroll1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.payroll1.OnHoverTextColor = System.Drawing.Color.White
        Me.payroll1.selected = False
        Me.payroll1.Size = New System.Drawing.Size(190, 35)
        Me.payroll1.TabIndex = 10
        Me.payroll1.Text = "         PAYROLL"
        Me.payroll1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.payroll1.Textcolor = System.Drawing.Color.White
        Me.payroll1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'cashadv1
        '
        Me.cashadv1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.cashadv1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.cashadv1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.cashadv1.BorderRadius = 5
        Me.cashadv1.ButtonText = "CASH ADVANCE"
        Me.cashadv1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cashadv1.DisabledColor = System.Drawing.Color.Gray
        Me.cashadv1.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cashadv1.Iconcolor = System.Drawing.Color.Transparent
        Me.cashadv1.Iconimage = CType(resources.GetObject("cashadv1.Iconimage"), System.Drawing.Image)
        Me.cashadv1.Iconimage_right = Nothing
        Me.cashadv1.Iconimage_right_Selected = Nothing
        Me.cashadv1.Iconimage_Selected = Nothing
        Me.cashadv1.IconMarginLeft = 0
        Me.cashadv1.IconMarginRight = 0
        Me.cashadv1.IconRightVisible = True
        Me.cashadv1.IconRightZoom = 0.0R
        Me.cashadv1.IconVisible = True
        Me.cashadv1.IconZoom = 80.0R
        Me.cashadv1.IsTab = False
        Me.cashadv1.Location = New System.Drawing.Point(17, 14)
        Me.cashadv1.Name = "cashadv1"
        Me.cashadv1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.cashadv1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.cashadv1.OnHoverTextColor = System.Drawing.Color.White
        Me.cashadv1.selected = False
        Me.cashadv1.Size = New System.Drawing.Size(190, 35)
        Me.cashadv1.TabIndex = 9
        Me.cashadv1.Text = "CASH ADVANCE"
        Me.cashadv1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cashadv1.Textcolor = System.Drawing.Color.White
        Me.cashadv1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Location = New System.Drawing.Point(5, 248)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(435, 28)
        Me.Panel4.TabIndex = 25
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Candara", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(3, 3)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(110, 18)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Select an Action"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(802, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(36, 28)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(410, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(36, 23)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(-1, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(479, 26)
        Me.Panel1.TabIndex = 6
        '
        'frmSelectAction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(444, 283)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmSelectAction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmSelectAction"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents mn As System.Windows.Forms.TextBox
    Friend WithEvents fn As System.Windows.Forms.TextBox
    Friend WithEvents ln As System.Windows.Forms.TextBox
    Friend WithEvents empid1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents deductions1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents printempinfo1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents payroll1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents cashadv1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
