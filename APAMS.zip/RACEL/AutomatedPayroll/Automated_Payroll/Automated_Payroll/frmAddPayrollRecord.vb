﻿Public Class frmAddPayrollRecord
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Hide()
    End Sub

    Private Sub add1_Click(sender As Object, e As EventArgs) Handles add1.Click
        Dim dt As DataTable
        Dim n1 As Integer
        n1 = workingdays1.Text
        dt = exec("insert into payroll(emp_id,lname,fname,mname,position,status,datehired,workingdays,basicpay,grosspay,cashadvance,sss,pagibig,philhealth,others,deductions,netpay) values('" & empid1.Text & "','" & ln.Text & "','" & fn.Text & "','" & mn.Text & "','" & position1.Text & "','" & status1.Text & "','" & date1.Text & "','" & workingdays1.Text & "','" & basicpay1.Text & "','" & grosspay1.Text & "','" & cashadvance1.Text & "','" & sss1.Text & "','" & pagibig1.Text & "','" & philhealth1.Text & "','" & others1.Text & "','" & dedcutions1.Text & "','" & netpay1.Text & "')")
        If dt.Rows.Count > 0 Then
            MsgBox("Success")
        Else
            MsgBox("Failed")
        End If

    End Sub
    Sub sss()

        If Label16.Text <= 1249.99 Then
            sss1.Text = 110
        ElseIf Label16.Text <= 1749.99 Then
            sss1.Text = 165
        ElseIf Label16.Text <= 2249.99 Then
            sss1.Text = 220
        ElseIf Label16.Text <= 2749.99 Then
            sss1.Text = 275
        ElseIf Label16.Text <= 3249.99 Then
            sss1.Text = 330
        ElseIf Label16.Text <= 3749.99 Then
            sss1.Text = 385
        ElseIf Label16.Text <= 4249.99 Then
            sss1.Text = 440
        ElseIf Label16.Text <= 4749.99 Then
            sss1.Text = 495
        ElseIf Label16.Text <= 5249.99 Then
            sss1.Text = 550
        ElseIf Label16.Text <= 5749.99 Then
            sss1.Text = 605
        ElseIf Label16.Text <= 6249.99 Then
            sss1.Text = 660
        ElseIf Label16.Text <= 6749.99 Then
            sss1.Text = 715
        ElseIf Label16.Text <= 7249.99 Then
            sss1.Text = 770
        ElseIf Label16.Text <= 7749.99 Then
            sss1.Text = 825
        ElseIf Label16.Text <= 8249.99 Then
            sss1.Text = 880
        ElseIf Label16.Text <= 8749.99 Then
            sss1.Text = 935
        ElseIf Label16.Text <= 9249.99 Then
            sss1.Text = 990
        ElseIf Label16.Text <= 9749.99 Then
            sss1.Text = 1045
        ElseIf Label16.Text <= 10249.99 Then
            sss1.Text = 1100
        ElseIf Label16.Text <= 10749.99 Then
            sss1.Text = 1155
        ElseIf Label16.Text <= 11249.99 Then
            sss1.Text = 1210
        ElseIf Label16.Text <= 11749.99 Then
            sss1.Text = 1265
        ElseIf Label16.Text <= 12249.99 Then
            sss1.Text = 1320
        ElseIf Label16.Text <= 12749.99 Then
            sss1.Text = 1375
        ElseIf Label16.Text <= 13249.99 Then
            sss1.Text = 1430
        ElseIf Label16.Text <= 13749.99 Then
            sss1.Text = 1485
        ElseIf Label16.Text <= 14249.99 Then
            sss1.Text = 1540
        ElseIf Label16.Text <= 14749.99 Then
            sss1.Text = 1595
        ElseIf Label16.Text <= 15249.99 Then
            sss1.Text = 1650
        ElseIf Label16.Text <= 15749.99 Then
            sss1.Text = 1705
        ElseIf Label16.Text >= 15749.99 Then
            sss1.Text = 1760
        End If

    End Sub
    Private Sub frmAddPayrollRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sum As Double

        sss()
        workingdays1.Text = Label16.Text / 480
        sum = Val(cashadvance1.Text) + Val(sss1.Text) + Val(pagibig1.Text) + Val(philhealth1.Text)
        need()
        basicpay1.Text = Label21.Text * 12
        Label22.Text = Label16.Text * Label20.Text
        grosspay1.Text = others1.Text + Label22.Text
        dedcutions1.Text = sum
        netpay1.Text = Label22.Text - dedcutions1.Text
    End Sub
    Sub need()
        Dim dt As DataTable
        dt = exec("select * from position where position = '" & position1.Text & "' ")
        If dt.Rows.Count > 0 Then
            Label20.Text = dt.Rows(0).Item(3).ToString
            Label21.Text = dt.Rows(0).Item(1).ToString
        End If
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub Panel6_Paint(sender As Object, e As PaintEventArgs) Handles Panel6.Paint

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub workingdays1_TextChanged(sender As Object, e As EventArgs) Handles workingdays1.TextChanged

    End Sub
End Class