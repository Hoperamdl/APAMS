﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Usercontrol_employeerecord
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Usercontrol_employeerecord))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BunifuGradientPanel1 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.add1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.search1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.search = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.dgemp = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BunifuGradientPanel1.SuspendLayout()
        CType(Me.dgemp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Candara", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(133, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(195, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "EMPLOYEE RECORD"
        '
        'BunifuGradientPanel1
        '
        Me.BunifuGradientPanel1.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.BunifuGradientPanel1.Controls.Add(Me.Label3)
        Me.BunifuGradientPanel1.Controls.Add(Me.Label2)
        Me.BunifuGradientPanel1.Controls.Add(Me.add1)
        Me.BunifuGradientPanel1.Controls.Add(Me.search1)
        Me.BunifuGradientPanel1.Controls.Add(Me.search)
        Me.BunifuGradientPanel1.Controls.Add(Me.ComboBox1)
        Me.BunifuGradientPanel1.Controls.Add(Me.dgemp)
        Me.BunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.Location = New System.Drawing.Point(26, 59)
        Me.BunifuGradientPanel1.Name = "BunifuGradientPanel1"
        Me.BunifuGradientPanel1.Quality = 10
        Me.BunifuGradientPanel1.Size = New System.Drawing.Size(1089, 490)
        Me.BunifuGradientPanel1.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Candara", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(1006, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(20, 23)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(844, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(164, 19)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Number of Employees:"
        '
        'add1
        '
        Me.add1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.add1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.add1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.add1.BorderRadius = 5
        Me.add1.ButtonText = "ADD"
        Me.add1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.add1.DisabledColor = System.Drawing.Color.Gray
        Me.add1.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.add1.Iconcolor = System.Drawing.Color.Transparent
        Me.add1.Iconimage = CType(resources.GetObject("add1.Iconimage"), System.Drawing.Image)
        Me.add1.Iconimage_right = Nothing
        Me.add1.Iconimage_right_Selected = Nothing
        Me.add1.Iconimage_Selected = Nothing
        Me.add1.IconMarginLeft = 0
        Me.add1.IconMarginRight = 0
        Me.add1.IconRightVisible = True
        Me.add1.IconRightZoom = 0.0R
        Me.add1.IconVisible = True
        Me.add1.IconZoom = 80.0R
        Me.add1.IsTab = False
        Me.add1.Location = New System.Drawing.Point(404, 35)
        Me.add1.Name = "add1"
        Me.add1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.add1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.add1.OnHoverTextColor = System.Drawing.Color.White
        Me.add1.selected = False
        Me.add1.Size = New System.Drawing.Size(86, 35)
        Me.add1.TabIndex = 4
        Me.add1.Text = "ADD"
        Me.add1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.add1.Textcolor = System.Drawing.Color.White
        Me.add1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'search1
        '
        Me.search1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.search1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.search1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.search1.BorderRadius = 5
        Me.search1.ButtonText = "SEARCH"
        Me.search1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.search1.DisabledColor = System.Drawing.Color.Gray
        Me.search1.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.search1.Iconcolor = System.Drawing.Color.Transparent
        Me.search1.Iconimage = CType(resources.GetObject("search1.Iconimage"), System.Drawing.Image)
        Me.search1.Iconimage_right = Nothing
        Me.search1.Iconimage_right_Selected = Nothing
        Me.search1.Iconimage_Selected = Nothing
        Me.search1.IconMarginLeft = 0
        Me.search1.IconMarginRight = 0
        Me.search1.IconRightVisible = True
        Me.search1.IconRightZoom = 0.0R
        Me.search1.IconVisible = True
        Me.search1.IconZoom = 85.0R
        Me.search1.IsTab = False
        Me.search1.Location = New System.Drawing.Point(274, 35)
        Me.search1.Name = "search1"
        Me.search1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.search1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.search1.OnHoverTextColor = System.Drawing.Color.White
        Me.search1.selected = False
        Me.search1.Size = New System.Drawing.Size(124, 35)
        Me.search1.TabIndex = 3
        Me.search1.Text = "SEARCH"
        Me.search1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.search1.Textcolor = System.Drawing.Color.White
        Me.search1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'search
        '
        Me.search.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.search.Location = New System.Drawing.Point(148, 40)
        Me.search.Name = "search"
        Me.search.Size = New System.Drawing.Size(125, 27)
        Me.search.TabIndex = 2
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Employee ID", "Last Name", "Middle Name", "First Name", "Gender"})
        Me.ComboBox1.Location = New System.Drawing.Point(17, 40)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(130, 27)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.Text = "Search by"
        '
        'dgemp
        '
        Me.dgemp.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgemp.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgemp.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.dgemp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgemp.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgemp.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgemp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgemp.DoubleBuffered = True
        Me.dgemp.EnableHeadersVisualStyles = False
        Me.dgemp.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.dgemp.HeaderForeColor = System.Drawing.Color.White
        Me.dgemp.Location = New System.Drawing.Point(17, 93)
        Me.dgemp.Name = "dgemp"
        Me.dgemp.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgemp.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgemp.Size = New System.Drawing.Size(1055, 377)
        Me.dgemp.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(27, 10)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Usercontrol_employeerecord
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.BunifuGradientPanel1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Usercontrol_employeerecord"
        Me.Size = New System.Drawing.Size(1158, 592)
        Me.BunifuGradientPanel1.ResumeLayout(False)
        Me.BunifuGradientPanel1.PerformLayout()
        CType(Me.dgemp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BunifuGradientPanel1 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents search1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents search As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents add1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents dgemp As Bunifu.Framework.UI.BunifuCustomDataGrid

End Class
