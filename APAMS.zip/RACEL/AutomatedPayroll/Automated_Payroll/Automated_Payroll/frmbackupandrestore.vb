﻿
Imports System.Data.SqlClient
Public Class frmbackupandrestore
    Dim con, con1 As SqlConnection
    Dim cmd1 As SqlCommand
    Dim dread As SqlDataReader


    Sub server(ByVal str As String)
        Try

            con = New SqlConnection("Data Source=GATUS-PC\SQLEXPRESS;Initial Catalog=Automatedpayroll_Capstone;Integrated Security=True")
            con.Open()
            cmd1 = New SqlCommand("select *  from sysservers  where srvproduct='SQL Server'", con)
            dread = cmd1.ExecuteReader
            While dread.Read
                cmbserver.Items.Add(dread(2))
            End While
            dread.Close()
        Catch ex As Exception

        End Try

    End Sub
    Sub connection()
        Try
            con = New SqlConnection("Data Source=GATUS-PC\SQLEXPRESS;Initial Catalog=Automatedpayroll_Capstone;Integrated Security=True")
            con.Open()
            cmbdatabase.Items.Clear()
            cmd1 = New SqlCommand("select * from sysdatabases", con)
            dread = cmd1.ExecuteReader
            While dread.Read
                cmbdatabase.Items.Add(dread(0))
            End While
            dread.Close()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub cmbserver_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbserver.SelectedIndexChanged
        connection()
        cmbserver.SelectedItem = 1
    End Sub
    Sub querys(ByVal que As String)
        On Error Resume Next
        cmd1 = New SqlCommand(que, con)
        cmd1.ExecuteNonQuery()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value = 100 Then
            Timer1.Enabled = False
            ProgressBar1.Visible = False
            MsgBox("Successfully Done")
            Me.Close()

        Else
            ProgressBar1.Value = ProgressBar1.Value + 5
        End If
    End Sub
    Sub blank(ByVal str As String)

        Try
            If str = "backup" Then

                SaveFileDialog1.FileName = System.DateTime.Now.ToString("MMMM-dd-yyyy") & "-" & frmdashboard.time.Text
                SaveFileDialog1.ShowDialog()
                Timer1.Enabled = True
                ProgressBar1.Visible = True
                Dim s As String
                s = SaveFileDialog1.FileName

                querys("backup database Automatedpayroll_Capstone to disk='" & s & "'")

                Dim datenow As String = Date.Now.Date


            ElseIf str = "restore" Then

                OpenFileDialog1.ShowDialog()
                Timer1.Enabled = True
                ProgressBar1.Visible = True


                querys("USE MASTER ALTER DATABASE Automatedpayroll_Capstone SET SINGLE_USER WITH ROLLBACK IMMEDIATE DROP DATABASE Automatedpayroll_Capstone RESTORE DATABASE Automatedpayroll_Capstone FROM disk='" & OpenFileDialog1.FileName & "'")
                con.Open()
                MsgBox("The Software will automatically close")

            Else
                MsgBox("OK")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub confirmit(ByVal nm As String)

        Try
            cmd2 = "Select * from login where Password =  '" & pass.Text & "'"
            Query2(cmd2)

            If nm = "backitup" Then
                If res2.HasRows Then
                    blank("backup")
                Else
                    MsgBox("Wrong password")
                End If
            ElseIf nm = "restoreitup" Then
                If res2.HasRows Then
                    blank("restore")
                Else
                    MsgBox("Wrong password")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub cmbbackup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBackup.Click
        confirmit("backitup")


    End Sub

    Private Sub cmdrestore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrestore.Click
        confirmit("restoreitup")
    End Sub

    Private Sub backup_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        server(".")
        server(".\sqlexpress")
        cmbdatabase.Items.Add("Automatedpayroll_Capstone")
        cmbdatabase.SelectedIndex = 0
        cmbserver.SelectedIndex = 0
    End Sub


    
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub btnBackup_Click(sender As Object, e As EventArgs) Handles btnBackup.Click

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Close()
    End Sub
End Class
