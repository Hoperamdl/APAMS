﻿Imports System.Data
Imports System.IO
Imports System.Data.SqlClient
Public Class Usercontrol_employeerecord
    Dim conn As SqlConnection
    Dim dt As New DataTable
    Dim sqlDA As New SqlDataAdapter
    Dim connection As New SqlConnection("Data Source=GATUS-PC\SQLEXPRESS;Initial Catalog=Automatedpayroll_Capstone;Integrated Security=True")

    Private Sub add1_Click(sender As Object, e As EventArgs) Handles add1.Click
        frmAddEmployee.Show()
        refress()
        frmAddEmployee.prodname()
    End Sub

    Private Sub edit1_Click(sender As Object, e As EventArgs)
        frmUpdateEmployee.Show()
    End Sub
    'Sub dg()
    '    Dim dt As DataTable
    '    dt = exec("Select * from employee")
    '    dgemp.DataSource = dt
    'End Sub
    ''ADD DATA GRDVIEW
    'Private Sub populate(empid1 As String, ln1 As String, fn1 As String, mn1 As String, gender1 As String, bday1 As String, label8 As String, bplace1 As String, address1 As String, cno1 As String, position1 As String, status1 As String, datehired1 As String)
    '    Dim row As String() = New String() {empid1, ln1, fn1, mn1, gender1, bday1, label8, bplace1, address1, cno1, position1, status1, datehired1}

    '    'ADD TO ROWS COLLECTION
    '    dgemp.Rows.Add(row)
    'End Sub
    'Private Sub usercontrol_load(inp_user As DataGridView)
    '    Dim useradapter As SqlDataAdapter
    '    Dim userds As DataSet
    '    Dim query As String
    '    query = "Select * from employee"
    '    SQLCON.Open()
    '    useradapter.SelectCommand = New SqlCommand(query, SQLCON)
    '    useradapter.Fill(userds, "employee")
    '    SQLCON.Close()
    '    inp_user.DataSource = userds.Tables("employee")
    'End Sub

    'Private Sub refresh1_Click(sender As Object, e As EventArgs) Handles refresh1.Click
    '    dg()
    'End Sub
    Public Sub datagridshow()
        Dim dt As DataTable

        dt = exec("Select * from employee where status = 'Contractual' or status = 'Regular'")


    End Sub
    Public Sub refress()
        FILLDGV("Select * from employee where status = 'Contractual' or status = 'Regular'", dgemp)
    End Sub
    Sub autocount()
        Dim dt As DataTable
        dt = exec("Select * from employee where status = 'Contractual' or status = 'Regular'")
        Label3.Text = dt.Rows.Count
    End Sub
    Private Sub Usercontrol_employeerecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        autocount()
        refress()
        datagridshow()
    End Sub

    

    Private Sub dgemp_Click(sender As Object, e As EventArgs) Handles dgemp.Click
        Dim form As New frmUpdateEmployee
        form.empid1.Text = dgemp.CurrentRow.Cells(0).Value.ToString
        form.ln.Text = dgemp.CurrentRow.Cells(1).Value.ToString
        form.fn.Text = dgemp.CurrentRow.Cells(2).Value.ToString
        form.mn.Text = dgemp.CurrentRow.Cells(3).Value.ToString
        form.gender1.Text = dgemp.CurrentRow.Cells(4).Value.ToString
        form.birhday1.Text = dgemp.CurrentRow.Cells(5).Value.ToString
        form.birthmonth1.Text = dgemp.CurrentRow.Cells(6).Value.ToString
        form.birthyear1.Text = dgemp.CurrentRow.Cells(7).Value.ToString
        form.Label8.Text = dgemp.CurrentRow.Cells(9).Value.ToString
        form.bplace1.Text = dgemp.CurrentRow.Cells(8).Value.ToString
        form.address1.Text = dgemp.CurrentRow.Cells(10).Value.ToString
        form.cno1.Text = dgemp.CurrentRow.Cells(11).Value.ToString
        form.position1.Text = dgemp.CurrentRow.Cells(12).Value.ToString
        form.datestart.Text = dgemp.CurrentRow.Cells(13).Value.ToString
        form.dateend.Text = dgemp.CurrentRow.Cells(14).Value.ToString
        form.status1.Text = dgemp.CurrentRow.Cells(15).Value.ToString
        form.TextBox1.Text = dgemp.CurrentRow.Cells(16).Value.ToString

        form.ShowDialog()
    End Sub

    Private Sub dgemp_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgemp.CellContentClick

    End Sub

 

    Private Sub search1_Click(sender As Object, e As EventArgs) Handles search1.Click
        ''Dim dt As DataTable
        ''dt = exec("select * from employee where emp_id = '" & search.Text & "'")
        refress()
    End Sub
    Public Sub FilterData(valueToSearch As String)
        Dim search As String = "SELECT * from employee WHERE CONCAT(emp_id,lname,fname,mname,gender,bmonth,byear,bday,address,age,bplace,cno,position,status,datehired,bioname) like '%" & valueToSearch & "%'"
        Dim command As New SqlCommand(search, connection)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable()
        adapter.Fill(table)
        dgemp.DataSource = table
    End Sub
  

    Private Sub search_TextChanged(sender As Object, e As EventArgs) Handles search.TextChanged
        FilterData(search1.Text)

    End Sub
End Class
