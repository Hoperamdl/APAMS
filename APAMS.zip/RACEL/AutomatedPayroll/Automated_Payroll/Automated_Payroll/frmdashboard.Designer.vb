﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmdashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmdashboard))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.datee = New System.Windows.Forms.Label()
        Me.time = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.nickname = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.shut = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.abouts = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.records = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.sett = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.viewrecord = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.hiderecord = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Usercontrol_employeerecord1 = New Automated_Payroll.Usercontrol_employeerecord()
        Me.Usercontroll_payroll1 = New Automated_Payroll.usercontroll_payroll()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1366, 150)
        Me.Panel1.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(1102, 85)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(37, 13)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Active"
        Me.Label9.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(1102, 60)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Label8"
        Me.Label8.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(1102, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(39, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Label7"
        Me.Label7.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Candara", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(504, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(337, 33)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "System for Bang's Company"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Candara", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(678, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(288, 33)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Attendance Monitoring"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Candara", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(391, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(281, 33)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Automated Payroll and"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(259, 21)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(126, 106)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.datee)
        Me.Panel2.Controls.Add(Me.time)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.nickname)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Location = New System.Drawing.Point(3, 154)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(195, 100)
        Me.Panel2.TabIndex = 1
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(-2, -2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 54)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'datee
        '
        Me.datee.AutoSize = True
        Me.datee.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datee.ForeColor = System.Drawing.Color.White
        Me.datee.Location = New System.Drawing.Point(72, 81)
        Me.datee.Name = "datee"
        Me.datee.Size = New System.Drawing.Size(37, 15)
        Me.datee.TabIndex = 13
        Me.datee.Text = "DATE"
        '
        'time
        '
        Me.time.AutoSize = True
        Me.time.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.time.ForeColor = System.Drawing.Color.White
        Me.time.Location = New System.Drawing.Point(71, 55)
        Me.time.Name = "time"
        Me.time.Size = New System.Drawing.Size(36, 15)
        Me.time.TabIndex = 12
        Me.time.Text = "TIME"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(26, 81)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 15)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "DATE:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(26, 55)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 15)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "TIME:"
        '
        'nickname
        '
        Me.nickname.AutoSize = True
        Me.nickname.ForeColor = System.Drawing.Color.White
        Me.nickname.Location = New System.Drawing.Point(113, 26)
        Me.nickname.Name = "nickname"
        Me.nickname.Size = New System.Drawing.Size(53, 13)
        Me.nickname.TabIndex = 1
        Me.nickname.Text = "nickname"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(113, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "WELCOME"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.BunifuFlatButton2)
        Me.Panel3.Controls.Add(Me.BunifuFlatButton1)
        Me.Panel3.Controls.Add(Me.shut)
        Me.Panel3.Controls.Add(Me.abouts)
        Me.Panel3.Controls.Add(Me.records)
        Me.Panel3.Controls.Add(Me.sett)
        Me.Panel3.Controls.Add(Me.viewrecord)
        Me.Panel3.Controls.Add(Me.hiderecord)
        Me.Panel3.Location = New System.Drawing.Point(3, 260)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(200, 490)
        Me.Panel3.TabIndex = 2
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 5
        Me.BunifuFlatButton2.ButtonText = "HIDE RECORD"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = CType(resources.GetObject("BunifuFlatButton2.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0.0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 90.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(7, 94)
        Me.BunifuFlatButton2.Margin = New System.Windows.Forms.Padding(5)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(186, 68)
        Me.BunifuFlatButton2.TabIndex = 7
        Me.BunifuFlatButton2.Text = "HIDE RECORD"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton1
        '
        Me.BunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.BunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.BunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton1.BorderRadius = 5
        Me.BunifuFlatButton1.ButtonText = "PAYROLL"
        Me.BunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton1.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton1.Iconimage = CType(resources.GetObject("BunifuFlatButton1.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton1.Iconimage_right = Nothing
        Me.BunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton1.Iconimage_Selected = Nothing
        Me.BunifuFlatButton1.IconMarginLeft = 0
        Me.BunifuFlatButton1.IconMarginRight = 0
        Me.BunifuFlatButton1.IconRightVisible = True
        Me.BunifuFlatButton1.IconRightZoom = 0.0R
        Me.BunifuFlatButton1.IconVisible = True
        Me.BunifuFlatButton1.IconZoom = 70.0R
        Me.BunifuFlatButton1.IsTab = False
        Me.BunifuFlatButton1.Location = New System.Drawing.Point(7, 94)
        Me.BunifuFlatButton1.Margin = New System.Windows.Forms.Padding(5)
        Me.BunifuFlatButton1.Name = "BunifuFlatButton1"
        Me.BunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.BunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.BunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton1.selected = False
        Me.BunifuFlatButton1.Size = New System.Drawing.Size(186, 68)
        Me.BunifuFlatButton1.TabIndex = 6
        Me.BunifuFlatButton1.Text = "PAYROLL"
        Me.BunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'shut
        '
        Me.shut.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.shut.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.shut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.shut.BorderRadius = 5
        Me.shut.ButtonText = "LOG OUT"
        Me.shut.Cursor = System.Windows.Forms.Cursors.Hand
        Me.shut.DisabledColor = System.Drawing.Color.Gray
        Me.shut.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.shut.Iconcolor = System.Drawing.Color.Transparent
        Me.shut.Iconimage = CType(resources.GetObject("shut.Iconimage"), System.Drawing.Image)
        Me.shut.Iconimage_right = Nothing
        Me.shut.Iconimage_right_Selected = Nothing
        Me.shut.Iconimage_Selected = Nothing
        Me.shut.IconMarginLeft = 0
        Me.shut.IconMarginRight = 0
        Me.shut.IconRightVisible = True
        Me.shut.IconRightZoom = 0.0R
        Me.shut.IconVisible = True
        Me.shut.IconZoom = 90.0R
        Me.shut.IsTab = False
        Me.shut.Location = New System.Drawing.Point(5, 406)
        Me.shut.Margin = New System.Windows.Forms.Padding(5)
        Me.shut.Name = "shut"
        Me.shut.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.shut.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.shut.OnHoverTextColor = System.Drawing.Color.White
        Me.shut.selected = False
        Me.shut.Size = New System.Drawing.Size(186, 68)
        Me.shut.TabIndex = 4
        Me.shut.Text = "LOG OUT"
        Me.shut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.shut.Textcolor = System.Drawing.Color.White
        Me.shut.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'abouts
        '
        Me.abouts.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.abouts.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.abouts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.abouts.BorderRadius = 5
        Me.abouts.ButtonText = "ABOUT"
        Me.abouts.Cursor = System.Windows.Forms.Cursors.Hand
        Me.abouts.DisabledColor = System.Drawing.Color.Gray
        Me.abouts.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.abouts.Iconcolor = System.Drawing.Color.Transparent
        Me.abouts.Iconimage = CType(resources.GetObject("abouts.Iconimage"), System.Drawing.Image)
        Me.abouts.Iconimage_right = Nothing
        Me.abouts.Iconimage_right_Selected = Nothing
        Me.abouts.Iconimage_Selected = Nothing
        Me.abouts.IconMarginLeft = 0
        Me.abouts.IconMarginRight = 0
        Me.abouts.IconRightVisible = True
        Me.abouts.IconRightZoom = 0.0R
        Me.abouts.IconVisible = True
        Me.abouts.IconZoom = 90.0R
        Me.abouts.IsTab = False
        Me.abouts.Location = New System.Drawing.Point(5, 328)
        Me.abouts.Margin = New System.Windows.Forms.Padding(5)
        Me.abouts.Name = "abouts"
        Me.abouts.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.abouts.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.abouts.OnHoverTextColor = System.Drawing.Color.White
        Me.abouts.selected = False
        Me.abouts.Size = New System.Drawing.Size(186, 68)
        Me.abouts.TabIndex = 3
        Me.abouts.Text = "ABOUT"
        Me.abouts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.abouts.Textcolor = System.Drawing.Color.White
        Me.abouts.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'records
        '
        Me.records.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.records.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.records.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.records.BorderRadius = 5
        Me.records.ButtonText = "RECORDS"
        Me.records.Cursor = System.Windows.Forms.Cursors.Hand
        Me.records.DisabledColor = System.Drawing.Color.Gray
        Me.records.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.records.Iconcolor = System.Drawing.Color.Transparent
        Me.records.Iconimage = CType(resources.GetObject("records.Iconimage"), System.Drawing.Image)
        Me.records.Iconimage_right = Nothing
        Me.records.Iconimage_right_Selected = Nothing
        Me.records.Iconimage_Selected = Nothing
        Me.records.IconMarginLeft = 0
        Me.records.IconMarginRight = 0
        Me.records.IconRightVisible = True
        Me.records.IconRightZoom = 0.0R
        Me.records.IconVisible = True
        Me.records.IconZoom = 90.0R
        Me.records.IsTab = False
        Me.records.Location = New System.Drawing.Point(5, 250)
        Me.records.Margin = New System.Windows.Forms.Padding(5)
        Me.records.Name = "records"
        Me.records.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.records.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.records.OnHoverTextColor = System.Drawing.Color.White
        Me.records.selected = False
        Me.records.Size = New System.Drawing.Size(186, 68)
        Me.records.TabIndex = 2
        Me.records.Text = "RECORDS"
        Me.records.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.records.Textcolor = System.Drawing.Color.White
        Me.records.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'sett
        '
        Me.sett.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.sett.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.sett.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sett.BorderRadius = 5
        Me.sett.ButtonText = "SETTINGS"
        Me.sett.Cursor = System.Windows.Forms.Cursors.Hand
        Me.sett.DisabledColor = System.Drawing.Color.Gray
        Me.sett.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sett.Iconcolor = System.Drawing.Color.Transparent
        Me.sett.Iconimage = CType(resources.GetObject("sett.Iconimage"), System.Drawing.Image)
        Me.sett.Iconimage_right = Nothing
        Me.sett.Iconimage_right_Selected = Nothing
        Me.sett.Iconimage_Selected = Nothing
        Me.sett.IconMarginLeft = 0
        Me.sett.IconMarginRight = 0
        Me.sett.IconRightVisible = True
        Me.sett.IconRightZoom = 0.0R
        Me.sett.IconVisible = True
        Me.sett.IconZoom = 70.0R
        Me.sett.IsTab = False
        Me.sett.Location = New System.Drawing.Point(7, 172)
        Me.sett.Margin = New System.Windows.Forms.Padding(5)
        Me.sett.Name = "sett"
        Me.sett.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.sett.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.sett.OnHoverTextColor = System.Drawing.Color.White
        Me.sett.selected = False
        Me.sett.Size = New System.Drawing.Size(186, 68)
        Me.sett.TabIndex = 1
        Me.sett.Text = "SETTINGS"
        Me.sett.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.sett.Textcolor = System.Drawing.Color.White
        Me.sett.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'viewrecord
        '
        Me.viewrecord.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.viewrecord.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.viewrecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.viewrecord.BorderRadius = 5
        Me.viewrecord.ButtonText = "VIEW RECORD"
        Me.viewrecord.Cursor = System.Windows.Forms.Cursors.Hand
        Me.viewrecord.DisabledColor = System.Drawing.Color.Gray
        Me.viewrecord.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.viewrecord.Iconcolor = System.Drawing.Color.Transparent
        Me.viewrecord.Iconimage = CType(resources.GetObject("viewrecord.Iconimage"), System.Drawing.Image)
        Me.viewrecord.Iconimage_right = Nothing
        Me.viewrecord.Iconimage_right_Selected = Nothing
        Me.viewrecord.Iconimage_Selected = Nothing
        Me.viewrecord.IconMarginLeft = 0
        Me.viewrecord.IconMarginRight = 0
        Me.viewrecord.IconRightVisible = True
        Me.viewrecord.IconRightZoom = 0.0R
        Me.viewrecord.IconVisible = True
        Me.viewrecord.IconZoom = 90.0R
        Me.viewrecord.IsTab = False
        Me.viewrecord.Location = New System.Drawing.Point(5, 16)
        Me.viewrecord.Margin = New System.Windows.Forms.Padding(5)
        Me.viewrecord.Name = "viewrecord"
        Me.viewrecord.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.viewrecord.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.viewrecord.OnHoverTextColor = System.Drawing.Color.White
        Me.viewrecord.selected = False
        Me.viewrecord.Size = New System.Drawing.Size(186, 68)
        Me.viewrecord.TabIndex = 0
        Me.viewrecord.Text = "VIEW RECORD"
        Me.viewrecord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.viewrecord.Textcolor = System.Drawing.Color.White
        Me.viewrecord.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'hiderecord
        '
        Me.hiderecord.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.hiderecord.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.hiderecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.hiderecord.BorderRadius = 5
        Me.hiderecord.ButtonText = "HIDE RECORD"
        Me.hiderecord.Cursor = System.Windows.Forms.Cursors.Hand
        Me.hiderecord.DisabledColor = System.Drawing.Color.Gray
        Me.hiderecord.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hiderecord.Iconcolor = System.Drawing.Color.Transparent
        Me.hiderecord.Iconimage = CType(resources.GetObject("hiderecord.Iconimage"), System.Drawing.Image)
        Me.hiderecord.Iconimage_right = Nothing
        Me.hiderecord.Iconimage_right_Selected = Nothing
        Me.hiderecord.Iconimage_Selected = Nothing
        Me.hiderecord.IconMarginLeft = 0
        Me.hiderecord.IconMarginRight = 0
        Me.hiderecord.IconRightVisible = True
        Me.hiderecord.IconRightZoom = 0.0R
        Me.hiderecord.IconVisible = True
        Me.hiderecord.IconZoom = 90.0R
        Me.hiderecord.IsTab = False
        Me.hiderecord.Location = New System.Drawing.Point(5, 16)
        Me.hiderecord.Margin = New System.Windows.Forms.Padding(5)
        Me.hiderecord.Name = "hiderecord"
        Me.hiderecord.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.hiderecord.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.hiderecord.OnHoverTextColor = System.Drawing.Color.White
        Me.hiderecord.selected = False
        Me.hiderecord.Size = New System.Drawing.Size(186, 68)
        Me.hiderecord.TabIndex = 5
        Me.hiderecord.Text = "HIDE RECORD"
        Me.hiderecord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.hiderecord.Textcolor = System.Drawing.Color.White
        Me.hiderecord.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Usercontrol_employeerecord1)
        Me.Panel4.Controls.Add(Me.Usercontroll_payroll1)
        Me.Panel4.Location = New System.Drawing.Point(204, 154)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1158, 596)
        Me.Panel4.TabIndex = 3
        '
        'Usercontrol_employeerecord1
        '
        Me.Usercontrol_employeerecord1.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Usercontrol_employeerecord1.Location = New System.Drawing.Point(0, 0)
        Me.Usercontrol_employeerecord1.Name = "Usercontrol_employeerecord1"
        Me.Usercontrol_employeerecord1.Size = New System.Drawing.Size(1158, 592)
        Me.Usercontrol_employeerecord1.TabIndex = 1
        '
        'Usercontroll_payroll1
        '
        Me.Usercontroll_payroll1.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Usercontroll_payroll1.Location = New System.Drawing.Point(0, 0)
        Me.Usercontroll_payroll1.Name = "Usercontroll_payroll1"
        Me.Usercontroll_payroll1.Size = New System.Drawing.Size(1158, 592)
        Me.Usercontroll_payroll1.TabIndex = 0
        '
        'frmdashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1366, 747)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmdashboard"
        Me.Text = "frmdashboard"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents datee As System.Windows.Forms.Label
    Friend WithEvents time As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents nickname As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents viewrecord As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents shut As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents abouts As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents records As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents sett As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents hiderecord As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents BunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Usercontrol_employeerecord1 As Automated_Payroll.Usercontrol_employeerecord
    Friend WithEvents Usercontroll_payroll1 As Automated_Payroll.usercontroll_payroll
    Friend WithEvents BunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
End Class
