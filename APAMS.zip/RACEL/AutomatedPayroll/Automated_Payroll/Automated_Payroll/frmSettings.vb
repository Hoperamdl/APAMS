﻿Public Class frmSettings
    Private Sub close1_Click(sender As Object, e As EventArgs)
        Me.Hide()
    End Sub
    Private Sub changeposition1_Click(sender As Object, e As EventArgs) Handles changeposition1.Click
        frmAddPosition.Show()
    End Sub

    Private Sub deductions1_Click(sender As Object, e As EventArgs) Handles deductions1.Click
        frmUpdateDeductions.Show()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Hide()
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        frmImportExcel.Show()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        frmUserLogs.Show()
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs)
        frmAddPayrollRecord.Show()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        frmbackupandrestore.Show()
    End Sub

    Private Sub cashadvance_Click(sender As Object, e As EventArgs) Handles cashadvance.Click
        frmCashAdvance.Show()
    End Sub

    Private Sub BunifuFlatButton3_Click_1(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        frmSelectAction.Show()
    End Sub
End Class