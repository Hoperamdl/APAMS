﻿Imports System.Data
Imports System.IO
Imports System.Data.SqlClient
Public Class usercontroll_payroll
    Private Sub add1_Click(sender As Object, e As EventArgs)
        frmAddEmployee.Show()
    End Sub

    Private Sub edit1_Click(sender As Object, e As EventArgs)
        frmUpdateEmployee.Show()
    End Sub
    'Sub dg()
    '    Dim dt As DataTable
    '    dt = exec("Select * from employee")
    '    dgemp.DataSource = dt
    'End Sub
    ''ADD DATA GRDVIEW
    'Private Sub populate(empid1 As String, ln1 As String, fn1 As String, mn1 As String, gender1 As String, bday1 As String, label8 As String, bplace1 As String, address1 As String, cno1 As String, position1 As String, status1 As String, datehired1 As String)
    '    Dim row As String() = New String() {empid1, ln1, fn1, mn1, gender1, bday1, label8, bplace1, address1, cno1, position1, status1, datehired1}

    '    'ADD TO ROWS COLLECTION
    '    dgemp.Rows.Add(row)
    'End Sub
    'Private Sub usercontrol_load(inp_user As DataGridView)
    '    Dim useradapter As SqlDataAdapter
    '    Dim userds As DataSet
    '    Dim query As String
    '    query = "Select * from employee"
    '    SQLCON.Open()
    '    useradapter.SelectCommand = New SqlCommand(query, SQLCON)
    '    useradapter.Fill(userds, "employee")
    '    SQLCON.Close()
    '    inp_user.DataSource = userds.Tables("employee")
    'End Sub

    'Private Sub refresh1_Click(sender As Object, e As EventArgs) Handles refresh1.Click
    '    dg()
    'End Sub
    Public Sub datagridshow()
        '   Dim dt As DataTable

        '     dt = exec("SELECT employee.employee_id, employee.lname, employee.fname, employee.mname, employee.position, employee.status,summary.employeename , summary.lowactual , cashadvandce.amount  FROM ((employee INNER JOIN summary ON employee.bioname = summary.employeename) INNER JOIN cashadvandce ON employee.emp_id = cashadvandce.emp_id) where employee.bioname = summary.employeename")


    End Sub
    Public Sub refress()
        FILLDGV("SELECT employee.employee_id, employee.last_name, employee.first_name, employee.middle_name, employee.position, employee.status,summary.employeename, summary.lowactual , cashadvandce.amount  FROM ((employee INNER JOIN summary ON employee.bioname = summary.employeename) INNER JOIN cashadvandce ON employee.employee_id = cashadvandce.emp_id) where employee.bioname = summary.employeename", dgemp)
    End Sub
    Private Sub Usercontrol_payroll_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        refress()
        datagridshow()
    End Sub

    Private Sub refresh1_Click(sender As Object, e As EventArgs)
        datagridshow()
        frmdashboard.Usercontrol_employeerecord1.datagridshow()
    End Sub

    Private Sub BunifuGradientPanel1_Paint(sender As Object, e As PaintEventArgs) Handles BunifuGradientPanel1.Paint

    End Sub

    Private Sub dgemp_Click(sender As Object, e As EventArgs) Handles dgemp.Click
        Dim form As New frmAddPayrollRecord

        form.empid1.Text = dgemp.CurrentRow.Cells(0).Value.ToString
        form.ln.Text = dgemp.CurrentRow.Cells(1).Value.ToString
        form.fn.Text = dgemp.CurrentRow.Cells(2).Value.ToString
        form.mn.Text = dgemp.CurrentRow.Cells(3).Value.ToString
        form.position1.Text = dgemp.CurrentRow.Cells(4).Value.ToString
        form.status1.Text = dgemp.CurrentRow.Cells(5).Value.ToString
        form.cashadvance1.Text = dgemp.CurrentRow.Cells(8).Value.ToString
        form.Label16.Text = dgemp.CurrentRow.Cells(7).Value.ToString
        form.date1.Text = frmdashboard.datee.Text
        form.workingdays1.Text = frmAddPayrollRecord.Label16.Text / 480
        form.ShowDialog()
    End Sub
    Sub marine()
        Dim form As New frmAddPayrollRecord

        If Form.label16.text = 1000 <= 1250 Then
            form.sss1.Text = 110
        End If
    End Sub
    Private Sub dgemp_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgemp.CellContentClick

    End Sub
End Class
