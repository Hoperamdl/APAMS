﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmlogin))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.login = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.log = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.cancel = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.username = New System.Windows.Forms.TextBox()
        Me.password = New System.Windows.Forms.TextBox()
        Me.timein = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(526, 35)
        Me.Panel1.TabIndex = 0
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(468, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(55, 35)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Candara", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(65, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(310, 15)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Automated Payroll and Attendance Monitoring System"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(4, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(55, 35)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria Math", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(75, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(155, 106)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "USERNAME:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Cambria Math", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(75, 110)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(154, 106)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "PASSWORD:"
        '
        'login
        '
        Me.login.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.login.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.login.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.login.BorderRadius = 0
        Me.login.ButtonText = "LOGIN"
        Me.login.Cursor = System.Windows.Forms.Cursors.Hand
        Me.login.DisabledColor = System.Drawing.Color.Gray
        Me.login.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.login.Iconcolor = System.Drawing.Color.Transparent
        Me.login.Iconimage = CType(resources.GetObject("login.Iconimage"), System.Drawing.Image)
        Me.login.Iconimage_right = Nothing
        Me.login.Iconimage_right_Selected = Nothing
        Me.login.Iconimage_Selected = Nothing
        Me.login.IconMarginLeft = 0
        Me.login.IconMarginRight = 0
        Me.login.IconRightVisible = True
        Me.login.IconRightZoom = 0.0R
        Me.login.IconVisible = True
        Me.login.IconZoom = 90.0R
        Me.login.IsTab = False
        Me.login.Location = New System.Drawing.Point(83, 1397)
        Me.login.Margin = New System.Windows.Forms.Padding(5, 21, 5, 21)
        Me.login.Name = "login"
        Me.login.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.login.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.login.OnHoverTextColor = System.Drawing.Color.White
        Me.login.selected = False
        Me.login.Size = New System.Drawing.Size(257, 424)
        Me.login.TabIndex = 5
        Me.login.Text = "LOGIN"
        Me.login.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.login.Textcolor = System.Drawing.Color.White
        Me.login.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'log
        '
        Me.log.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.log.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.log.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.log.BorderRadius = 5
        Me.log.ButtonText = "LOGIN"
        Me.log.Cursor = System.Windows.Forms.Cursors.Hand
        Me.log.DisabledColor = System.Drawing.Color.Gray
        Me.log.Iconcolor = System.Drawing.Color.Transparent
        Me.log.Iconimage = CType(resources.GetObject("log.Iconimage"), System.Drawing.Image)
        Me.log.Iconimage_right = Nothing
        Me.log.Iconimage_right_Selected = Nothing
        Me.log.Iconimage_Selected = Nothing
        Me.log.IconMarginLeft = 0
        Me.log.IconMarginRight = 0
        Me.log.IconRightVisible = True
        Me.log.IconRightZoom = 0.0R
        Me.log.IconVisible = True
        Me.log.IconZoom = 90.0R
        Me.log.IsTab = False
        Me.log.Location = New System.Drawing.Point(173, 200)
        Me.log.Name = "log"
        Me.log.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.log.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.log.OnHoverTextColor = System.Drawing.Color.White
        Me.log.selected = False
        Me.log.Size = New System.Drawing.Size(121, 51)
        Me.log.TabIndex = 6
        Me.log.Text = "LOGIN"
        Me.log.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.log.Textcolor = System.Drawing.Color.White
        Me.log.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 10
        Me.BunifuElipse1.TargetControl = Me
        '
        'cancel
        '
        Me.cancel.Activecolor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.cancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.cancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.cancel.BorderRadius = 5
        Me.cancel.ButtonText = "CANCEL"
        Me.cancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cancel.DisabledColor = System.Drawing.Color.Gray
        Me.cancel.Iconcolor = System.Drawing.Color.Transparent
        Me.cancel.Iconimage = CType(resources.GetObject("cancel.Iconimage"), System.Drawing.Image)
        Me.cancel.Iconimage_right = Nothing
        Me.cancel.Iconimage_right_Selected = Nothing
        Me.cancel.Iconimage_Selected = Nothing
        Me.cancel.IconMarginLeft = 0
        Me.cancel.IconMarginRight = 0
        Me.cancel.IconRightVisible = True
        Me.cancel.IconRightZoom = 0.0R
        Me.cancel.IconVisible = True
        Me.cancel.IconZoom = 90.0R
        Me.cancel.IsTab = False
        Me.cancel.Location = New System.Drawing.Point(300, 200)
        Me.cancel.Name = "cancel"
        Me.cancel.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.cancel.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.cancel.OnHoverTextColor = System.Drawing.Color.White
        Me.cancel.selected = False
        Me.cancel.Size = New System.Drawing.Size(121, 51)
        Me.cancel.TabIndex = 7
        Me.cancel.Text = "CANCEL"
        Me.cancel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cancel.Textcolor = System.Drawing.Color.White
        Me.cancel.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'username
        '
        Me.username.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.username.Location = New System.Drawing.Point(226, 88)
        Me.username.Name = "username"
        Me.username.Size = New System.Drawing.Size(195, 26)
        Me.username.TabIndex = 8
        '
        'password
        '
        Me.password.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.password.Location = New System.Drawing.Point(226, 146)
        Me.password.Name = "password"
        Me.password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.password.Size = New System.Drawing.Size(195, 26)
        Me.password.TabIndex = 9
        '
        'timein
        '
        Me.timein.AutoSize = True
        Me.timein.Location = New System.Drawing.Point(420, 42)
        Me.timein.Name = "timein"
        Me.timein.Size = New System.Drawing.Size(39, 13)
        Me.timein.TabIndex = 10
        Me.timein.Text = "Label4"
        Me.timein.Visible = False
        '
        'Timer1
        '
        '
        'frmlogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(524, 278)
        Me.Controls.Add(Me.timein)
        Me.Controls.Add(Me.password)
        Me.Controls.Add(Me.username)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.log)
        Me.Controls.Add(Me.login)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmlogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents login As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents log As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents cancel As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents password As System.Windows.Forms.TextBox
    Friend WithEvents username As System.Windows.Forms.TextBox
    Friend WithEvents timein As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
