﻿Public Class frmUpdateDeductions

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Hide()
    End Sub

    Private Sub save1_Click(sender As Object, e As EventArgs) Handles save1.Click

    End Sub
End Class