﻿Imports System.IO
Imports System.Data.SqlClient

Public Class frmAddEmployee

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Hide()
    End Sub
   

    Private Sub add1_Click(sender As Object, e As EventArgs) Handles add1.Click
        Try

            Dim dt As DataTable
            Dim ms As New MemoryStream
            PictureBox2.Image.Save(ms, PictureBox2.Image.RawFormat)
            If (empid1.Text = "" Or address1.Text = "" Or fn.Text = "" Or mn.Text = "" Or ln.Text = "" Or gender1.Text = "" Or birthyear1.Text = "" Or birhday1.Text = "" Or birthmonth1.Text = "" Or Label8.Text = "" Or bplace1.Text = "" Or cno1.Text = "" Or position1.Text = "" Or datestart.Text = "" Or dateend.Text = "" Or status1.Text = "") Then
                MsgBox("Fill the blanks")
            Else
                dt = exec("insert into employee(EMPLOYEE_ID,LAST_NAME,FIRST_NAME,MIDDLE_NAME,GENDER,BIRTH_MONTH,BIRTH_DAY,BIRTH_YEAR,AGE,BIRTH_PLACE,ADDRESS,CONTACT_NUMBER,POSITION,DATE_START,DATE_END,STATUS,IMAGE,BIONAME) values ('" & empid1.Text & "','" & ln.Text & "','" & fn.Text & "','" & mn.Text & "','" & gender1.Text & "','" & birthmonth1.Text & "','" & birhday1.Text & "','" & birthyear1.Text & "','" & Label8.Text & "','" & bplace1.Text & "','" & address1.Text & "','" & cno1.Text & "','" & position1.Text & "','" & datestart.Text & "','" & dateend.Text & "','" & status1.Text & "','" & PictureBox2.ToString & "','" & TextBox1.Text & "' ) ")

                MsgBox("Success")
                auto()
                frmdashboard.Usercontrol_employeerecord1.datagridshow()
                ln.Text = ""
                mn.Text = ""
                fn.Text = ""
                TextBox1.Text = ""
                birthmonth1.Text = "Month"
                birhday1.Text = "00"
                birthyear1.Text = "0000"
                Label8.Text = "0"
                bplace1.Text = ""
                address1.Text = ""
                cno1.Text = ""
                gender1.Text = ""
                position1.Text = ""
                datestart.Text = ""
                dateend.Text = ""
                status1.Text = ""
                frmdashboard.Usercontrol_employeerecord1.datagridshow()
                frmdashboard.Usercontrol_employeerecord1.refress()

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub browse1_Click(sender As Object, e As EventArgs) Handles browse1.Click
        Dim opf As New OpenFileDialog
        opf.Filter = "Choose Image (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif"
        opf.FilterIndex = 4
        opf.FileName = ""


        If opf.ShowDialog() = DialogResult.OK Then
            PictureBox2.Image = Image.FromFile(opf.FileName)
        End If
    End Sub
    Sub age()
        If birthyear1.Text = "" Or Label8.Text < 0 Then
            Label8.Text = "0"
        Else

            Dim myAge As New Integer
            myAge = DateTime.Today.Year - birthyear1.Text
            Label8.Text = myAge.ToString()
        End If

    End Sub
    Private Sub bday1_onValueChanged(sender As Object, e As EventArgs)
        Dim myAge As New Integer
        myAge = DateTime.Today.Year - birthyear1.Text
        Label8.Text = myAge.ToString()
    End Sub
    Public Sub auto()
        Dim row As DataTable
        row = ModConn.exec("SELECT MAX([EMPLOYEE_ID]) FROM [Automatedpayroll_Capstone].[dbo].[employee] ")
        If row.Rows.Count > 0 Then
            empid1.Text = "EMP-" & (Str(Val(row.Rows(0).Item(0).ToString.Replace("EMP-", ""))) + 1).ToString("000000")
        Else
            empid1.Text = "EMP-000001"
        End If

    End Sub
    Private Sub frmAddEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        auto()
    End Sub

    Private Sub ln_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ln.KeyPress
        Static PrevLetterCat As Char
        If PrevLetterCat = " " Or ln.Text.Length = 0 Then
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
        PrevLetterCat = e.KeyChar

        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowedChars As String = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowedChars.Contains(e.KeyChar.ToString) Then
                e.KeyChar = ChrW(0)
                e.Handled = True
                MsgBox("Enter Letters Only")
            End If
        End If
    End Sub

    Private Sub fn_KeyPress(sender As Object, e As KeyPressEventArgs) Handles fn.KeyPress
        Static PrevLetterCat As Char
        If PrevLetterCat = " " Or fn.Text.Length = 0 Then
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
        PrevLetterCat = e.KeyChar

        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowedChars As String = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowedChars.Contains(e.KeyChar.ToString) Then
                e.KeyChar = ChrW(0)
                e.Handled = True
                MsgBox("Enter Letters Only")
            End If
        End If
    End Sub

    Private Sub mn_KeyPress(sender As Object, e As KeyPressEventArgs) Handles mn.KeyPress
        Static PrevLetterCat As Char
        If PrevLetterCat = " " Or mn.Text.Length = 0 Then
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
        PrevLetterCat = e.KeyChar

        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowedChars As String = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowedChars.Contains(e.KeyChar.ToString) Then
                e.KeyChar = ChrW(0)
                e.Handled = True
                MsgBox("Enter Letters Only")
            End If
        End If
    End Sub

    Private Sub cno1_KeyPress(sender As Object, e As KeyPressEventArgs)
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") _
                   AndAlso e.KeyChar <> ControlChars.Back AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> "," AndAlso e.KeyChar <> "/" Then
            e.Handled = True
        End If
    End Sub

    Sub prodname()
        cmd = "select * from position"
        Query(cmd)
        While res.Read
            position1.Items.Add(res("position"))
        End While
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class