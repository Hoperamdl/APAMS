﻿Public Class frmUserLogs

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Hide()
    End Sub
    Public Sub datagridshow()
        Try

        Dim dt As DataTable

        dt = exec("select * from userlog")
        dt = exec("select * from useractivity")
        Catch ex As Exception

        End Try


    End Sub
    Public Sub refress()
        FILLDGV("select * from userlog", DataGridView1)
        FILLDGV("select * from useractivity", DataGridView2)
    End Sub
    Private Sub frmUserLogs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        refress()
        datagridshow()
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class