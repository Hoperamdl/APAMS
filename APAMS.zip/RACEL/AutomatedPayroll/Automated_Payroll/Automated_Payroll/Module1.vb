﻿Module Fill
    Public Sub FILLDGV(ByVal command As String, ByVal dgname As DataGridView)
        Dim dt As New DataTable
        dt = exec(command)
        dgname.DataSource = dt
    End Sub

End Module
