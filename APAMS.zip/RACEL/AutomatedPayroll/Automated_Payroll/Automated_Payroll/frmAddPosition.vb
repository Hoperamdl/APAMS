﻿Public Class frmAddPosition

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Hide()
    End Sub

    Private Sub cancel1_Click(sender As Object, e As EventArgs) Handles cancel1.Click
        Me.Hide()
    End Sub
    Sub ra()
        Dim no1 As New Double
        no1 = (Val(TextBox2.Text) / 8)

        TextBox3.Text = no1


    End Sub
    Sub cel()
        Dim no2 As New Double
        no2 = (TextBox3.Text / 60)
        TextBox4.Text = no2
    End Sub
    Private Sub frmChangePosition_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ra()
    End Sub
    Private Sub add1_Click(sender As Object, e As EventArgs) Handles add1.Click
        Try

            Dim dt As DataTable
            dt = exec("insert into position values('" & TextBox1.Text & "'," & TextBox2.Text & "," & TextBox3.Text & "," & TextBox4.Text & "")
            If dt.Rows.Count > 0 Then
                MsgBox("Failed")
            Else

                MsgBox("Success")
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub
End Class
