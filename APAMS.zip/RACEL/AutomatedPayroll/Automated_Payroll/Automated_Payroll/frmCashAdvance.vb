﻿Public Class frmCashAdvance

    Private Sub viewdata1_Click(sender As Object, e As EventArgs) Handles viewdata1.Click
        frmViewData.Show()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Hide()
    End Sub

    Private Sub date1_TextChanged(sender As Object, e As EventArgs) Handles date1.TextChanged

    End Sub

    Private Sub add1_Click(sender As Object, e As EventArgs) Handles add1.Click
        Dim dt As DataTable
        dt = exec("insert into cashadvance(emp_id,lname,fname,mname,amount,date)values('" & empid1.Text & "','" & ln.Text & "','" & fn.Text & "','" & mn.Text & "','" & amount1.Text & "','" & date1.Text & "')")
        If dt.Rows.Count > 0 Then
            MsgBox("Failed")
        Else
            MsgBox("Success")
        End If
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class