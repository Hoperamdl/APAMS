﻿Public Class frmdashboard
    Dim Usercontrol_employeerecords1 As UserControl
    Dim Usercontrol_payroll1 As New UserControl

    Private Sub sett_Click(sender As Object, e As EventArgs) Handles sett.Click
        frmSettings.Show()
    End Sub

    Private Sub records_Click(sender As Object, e As EventArgs) Handles records.Click
        frmRecords.Show()
    End Sub

    Private Sub shut_Click(sender As Object, e As EventArgs) Handles shut.Click
        Dim dt As DataTable
        dt = exec("insert into userlog values('" & Label7.Text & "','" & Label8.Text & "','" & time.Text & "','" & datee.Text & "','" & Label9.Text & "')")
        MsgBox("Are you sure you want to log out?")
        Me.Hide()
        frmlogin.username.Text = ""
        frmlogin.password.Text = ""
        frmlogin.Show()

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        time.Text = TimeOfDay.ToString("h:mm:ss tt")
        datee.Text = System.DateTime.Now.ToString("MMMM/dd/yyyy")
        frmAddEmployee.age()

        frmAddPosition.ra()
        frmAddPosition.cel()

    End Sub

    Private Sub frmdashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        refres()
    End Sub

    Private Sub viewrecord_Click(sender As Object, e As EventArgs) Handles viewrecord.Click
        Usercontrol_employeerecord1.Show()
        viewrecord.Hide()
        hiderecord.Show()
    End Sub

    Private Sub hiderecord_Click(sender As Object, e As EventArgs) Handles hiderecord.Click
        viewrecord.Show()
        Usercontrol_employeerecord1.Hide()
        hiderecord.Hide()
    End Sub

    Public Sub refres()
        FILLDGV("Select * from employee", Usercontrol_employeerecord1.dgemp)
    End Sub
    Private Sub Usercontrol_employeerecord1_Load(sender As Object, e As EventArgs)
        refres()
        Usercontrol_employeerecord1.datagridshow()
    End Sub

    Private Sub Usercontrol_employeerecord1_Load_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        Usercontroll_payroll1.Show()
        BunifuFlatButton2.Show()
        BunifuFlatButton1.Hide()
        Usercontroll_payroll1.refress()
        Usercontroll_payroll1.datagridshow()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Usercontroll_payroll1.Hide()
        BunifuFlatButton2.Hide()
        BunifuFlatButton1.Show()
        Usercontroll_payroll1.refress()
        Usercontroll_payroll1.datagridshow()

    End Sub


    Private Sub Usercontrol_employeerecord1_Load_2(sender As Object, e As EventArgs) Handles Usercontrol_employeerecord1.Load
        frmAddEmployee.Label8.Text = "0"
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class