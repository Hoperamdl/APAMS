﻿Imports System.Data
Public Class frmlogin

    Private Sub cancel_Click(sender As Object, e As EventArgs) Handles cancel.Click
        Me.Close()
    End Sub

    Private Sub log_Click(sender As Object, e As EventArgs) Handles log.Click


        Dim dt As New DataTable
        dt = exec("select * from login where username='" & username.Text & "'and Password='" & password.Text & "' ")
        If username.Text = "admin" And password.Text = "admin" Then

            Me.Hide()
            frmdashboard.Usercontrol_employeerecord1.Hide()
            frmdashboard.Show()
            frmdashboard.Label7.Text = username.Text
            frmdashboard.Label8.Text = timein.text
        ElseIf dt.Rows.Count > 0 Then

            Me.Hide()
            frmdashboard.Usercontrol_employeerecord1.Hide()
            frmdashboard.Show()


            MsgBox("Account Not Registered or Deactivated")
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        timein.Text = TimeOfDay.ToString("h:mm:ss tt")
    End Sub

    Private Sub frmlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub
End Class
