﻿Public Class frmSelectAction

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub cashadv1_Click(sender As Object, e As EventArgs) Handles cashadv1.Click
        frmCashAdvance.Show()
    End Sub

    Private Sub payroll1_Click(sender As Object, e As EventArgs) Handles payroll1.Click
        frmAddPayrollRecord.Show()
    End Sub

    Private Sub deductions1_Click(sender As Object, e As EventArgs) Handles deductions1.Click
        frmDeductions.Show()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Hide()
    End Sub
End Class