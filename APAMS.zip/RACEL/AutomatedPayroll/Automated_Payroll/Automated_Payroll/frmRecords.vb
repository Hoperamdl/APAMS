﻿Public Class frmRecords

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Hide()
    End Sub

    Private Sub BunifuCustomDataGrid4_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles payroll.CellContentClick

    End Sub
    Public Sub datagridshow()
        Dim dt As DataTable

        dt = exec("select * from payroll")
        dt = exec("select * from summary")
        dt = exec("select * from payrollstorage")
        dt = exec("select * from employee")
        dt = exec("select * from position")
        dt = exec("select * from cashadvandce")


    End Sub
    Public Sub refress()
        FILLDGV("select * from payroll", payroll)
        FILLDGV("select * from summary", summary)
        FILLDGV("select * from payrollstorage", payrollstorage)
        FILLDGV("select * from cashadvandce", cashadvance)
        FILLDGV("select * from employee", employee)
        FILLDGV("select * from position", position)
    End Sub
    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint

    End Sub

    Private Sub frmRecords_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        refress()
        datagridshow()
    End Sub

    Private Sub TabPage3_Click(sender As Object, e As EventArgs) Handles TabPage3.Click

    End Sub

    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox4.SelectedIndexChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click

    End Sub

    Private Sub employee_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles employee.CellContentClick

    End Sub
End Class