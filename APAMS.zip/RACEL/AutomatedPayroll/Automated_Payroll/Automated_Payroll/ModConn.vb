﻿Imports System.Data
Imports System.Data.SqlClient
Module ModConn
    Public Function exec(ByVal command As String) As DataTable
        Dim dt As New DataTable
        Try
            Dim conn As String = "Data Source=GATUS-PC\SQLEXPRESS;Initial Catalog=Automatedpayroll_Capstone;Integrated Security=True"
            Dim sqlDA As New SqlDataAdapter(command, conn)
            sqlDA.Fill(dt)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dt
    End Function

    Public SQLCON As New SqlConnection
    Public sqlcmd As SqlCommand
    Public sqlconstr As New SqlConnection
    Public res As SqlDataReader
    Public cmd As String
    Public Sub sqlconnection()
        If SQLCON.State = 1 Then SQLCON.Close()
        SQLCON.ConnectionString = "Data Source=GATUS-PC\SQLEXPRESS;Initial Catalog=Automatedpayroll_Capstone;Integrated Security=True"
        Try
            sqlcmd = New System.Data.SqlClient.SqlCommand
            SQLCON.Open()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Error in Database Connection")
        End Try
    End Sub
    Public Function Query(ByVal command As String) As String
        sqlconnection()
        sqlcmd.Connection = SQLCON
        cmd = command
        sqlcmd.CommandText = cmd
        res = sqlcmd.ExecuteReader
        Return True
    End Function
End Module
