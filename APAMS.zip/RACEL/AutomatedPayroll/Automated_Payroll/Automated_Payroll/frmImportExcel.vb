﻿Imports System.Data.SqlClient
Imports System.Data.OleDb

Public Class frmImportExcel
    Dim con As OleDbConnection
    Dim ds As DataSet
    Dim da As OleDbDataAdapter

    Sub insert()
        Dim dt As DataTable
        Try

            For i As Integer = 0 To DataGridView1.Rows.Count - 1

                dt = exec("insert into summary values('" & DataGridView1.Rows(i).Cells(0).Value & "','" & DataGridView1.Rows(i).Cells(1).Value & "','" & DataGridView1.Rows(i).Cells(2).Value & "','" & DataGridView1.Rows(i).Cells(3).Value & "','" & DataGridView1.Rows(i).Cells(4).Value & "','" & DataGridView1.Rows(i).Cells(5).Value & "','" & DataGridView1.Rows(i).Cells(6).Value & "','" & DataGridView1.Rows(i).Cells(7).Value & "','" & DataGridView1.Rows(i).Cells(8).Value & "','" & DataGridView1.Rows(i).Cells(9).Value & "','" & DataGridView1.Rows(i).Cells(10).Value & "','" & DataGridView1.Rows(i).Cells(11).Value & "','" & DataGridView1.Rows(i).Cells(12).Value & "','" & DataGridView1.Rows(i).Cells(13).Value & "','" & DataGridView1.Rows(i).Cells(14).Value & "','" & DataGridView1.Rows(i).Cells(15).Value & "','" & DataGridView1.Rows(i).Cells(16).Value & "','" & DataGridView1.Rows(i).Cells(17).Value & "','" & DataGridView1.Rows(i).Cells(18).Value & "','" & DataGridView1.Rows(i).Cells(19).Value & "','" & DataGridView1.Rows(i).Cells(20).Value & "','" & DataGridView1.Rows(i).Cells(21).Value & "','" & DataGridView1.Rows(i).Cells(22).Value & "')")
                'dt = exec("insert into emptble(emp_nname)values('" & DataGridView1.Rows(i).Cells(1).Value & "')")

            Next
            MsgBox("Insert Success!!!")
            DataGridView1.Columns.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MsgBox("Do you want to save all of this?")
        insert()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim op As New OpenFileDialog
        Dim partfile As String
        Try
            op.Filter = "All Files (*.*)|*.*|Excel Files (*.xlsx)|*.xlsx|XlS Files (*.xls)|*.xls"
            If op.ShowDialog = DialogResult.OK Then
                TextBox1.Text = op.FileName
                partfile = TextBox1.Text
                con = New OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0;Data Source= '" & partfile & "';Extended Properties=""Excel 12.0 Xml;HDR = yes""")
                da = New OleDbDataAdapter("Select * from [Summary$]", con)
                da.TableMappings.Add("Table", "Myfile")
                ds = New DataSet
                da.Fill(ds)
                ds.Tables(0).Rows.RemoveAt(0)
                ds.Tables(0).Rows.RemoveAt(0)
                ds.Tables(0).Rows.RemoveAt(0)

                DataGridView1.DataSource = ds.Tables(0)
                DataGridView1.Refresh()
                con.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Hide()
    End Sub
End Class